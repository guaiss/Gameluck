# Gameluck Popup Copywriting (EN)

## Fullscreen Interstitial / Center Popup 

### Title

Keep Playing, Start Earning!

### Subtitle

Just register on Gameluck and complete tasks to turn your game time into real cash.

### Bonus Tag

$5 Bonus for new user

### Main CTA Button

Start earning in Gameluck →

---

## Bottom Popup

### Header Title

Keep Playing, Start Earning!

---

### Benefit 1

**Title:**  
Play & Earn Extra  

**Description:**  
Get rewarded for playing Ball Sort through Gameluck.

---

### Benefit 2

**Title:**  
Instant Coin Reward  

**Description:**  
Get your in-game coins immediately once your Gameluck account is linked.

---

### Benefit 3

**Title:**  
$5 New User Bonus  

**Description:**  
New users get an instant $5 bonus upon successful registration.

---

### Main CTA Button

Start earning in Gameluck →

### Bonus Tag

$5 Bonus for new user